function validarFormulario() {

    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value.trim();

    let camposFaltantes = [];

    if (email === "") {
        camposFaltantes.push("email");
    }
    if (password === "") {
        camposFaltantes.push("password");

        if (camposFaltantes.length > 0) {
            alert("Por favor, completa los siguientes campos:\n" + camposFaltantes.join("\n"));
            return false;
        } else {
            // Si no hay campos faltantes, significa que el login fue exitoso
            alert("login exitoso");
            window.location.replace("index.html")
            return true;
        }
    }

    document
        .getElementById("loginForm")
        .addEventListener("submit", validarFormulario);
}